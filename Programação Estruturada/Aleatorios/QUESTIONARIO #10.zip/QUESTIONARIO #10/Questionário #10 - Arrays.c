#include <stdio.h>

#include <stdio.h>

int main(void){
    int palavra1, palavra2, a[50], b[50];
    int A = 0, B = 0, i = 0, j = 0;

    printf("Digite um palavra: ");
    palavra1 = getchar();

    while(palavra1 != '\n'){
        a[A] = palavra1;
        A = A + 1;
        i = i + palavra1;
        palavra1 = getchar();
    }

    printf("Digite outra palavra: ");
    palavra2 = getchar();

    while(palavra2 != '\n'){
        b[B] = palavra2;
        B = B + 1;
        j = j + palavra2;
        palavra2 = getchar();
    }


    if(i == j){
        printf("e um anagrama");
    }
    else{
        printf("nao e um anagrama");
    }
    return 0;
}

#include <stdio.h>

int horizontal(int x[],int y[]){
    int c;
    for (c = 0; c < 4; c += 1){
        printf("\n%d  ", y[c]);
        switch (c){
        case 0:
            printf("■■■■■■■■■■■\n\n");
            break;
        case 1:
            printf("■■■■■■\n\n");
            break;
        case 2:
            printf("■■■■■■■■■■■■■■■■■■■■■■■■\n\n");
            break;
        case 3:
            printf("■■■■■■■■■■■■■■■■■■\n\n");
            break;
        }
        if (c == 3){
            printf("     0");
        }

    }
    for (c = 0; c < 4; c += 1){
        printf("    %d", x[c]);

    }
}

int vertical(int x[],int y[]){
    int c;
    for (c = 3; c > (-1); c -= 1){
      printf("\n%d", x[c]);


      switch (c){
        case 3:
            printf("                  ▮\n                     ▮\n                     ▮");
            break;
        case 2:
            printf("                   ▮       ▮\n                     ▮       ▮\n                     ▮       ▮");
            break;
        case 1:
           printf("    ▮              ▮       ▮\n      ▮              ▮       ▮\n      ▮              ▮       ▮");
            break;
        case 0:
           printf("    ▮      ▮       ▮       ▮\n      ▮      ▮       ▮       ▮\n      ▮      ▮       ▮       ▮\n");
            break;
        }
      if(c==0){
        printf("0\n");
        }
    }
    for (c = 0; c < 4; c += 1){
        printf("    %d", y[c]);

}
}


int main(){
    int x[4] = {30,60,90,120}, y[4] = {2017, 2018, 2019, 2020};
    horizontal(x,y);
    printf("\n---------------------------------------------\n");
    vertical(x,y);
    return 0;
}




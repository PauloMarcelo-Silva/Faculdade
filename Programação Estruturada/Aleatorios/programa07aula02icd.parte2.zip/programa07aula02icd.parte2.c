#include <stdio.h>]
int main(void){
    int a = 10,b = 20;

    float x = 48.98,y = 55.67;

    printf("%5d",98);
    /*se eu colocar um %.5d ele me dara zeros pra completar,se eu colocar %5d
    ele ppulara linhas
    */
    return 0;
}




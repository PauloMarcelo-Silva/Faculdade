#include <stdio.h>

int main(void) {
    int i=10,j = 20;
    float x = 43.28, y = 52.47;

    printf("i=%d\n",i);
    printf("j=%d\n",j);
    printf("x=%.2f and y=%.2f",x,y);

    return 0;

}

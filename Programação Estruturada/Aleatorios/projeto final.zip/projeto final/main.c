#include <stdio.h>
#include <stdlib.h>
#include "matrix.h"
#include <math.h>

//aluno : paulo marcelo ribeiros soeiro da silva
//matricula : 20190040030

int main(void)
{
    int array[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    struct matrix a_matrix;

    struct matrix a_matrix, b_matrix, c_matrix;
    a_matrix = create_matrix(array, 5, 2);
    b_matrix = create_matrix(array, 2, 4);
    c_matrix = matmul(a_matrix, b_matrix);

    print_matrix(c_matrix);

    return 0;
}
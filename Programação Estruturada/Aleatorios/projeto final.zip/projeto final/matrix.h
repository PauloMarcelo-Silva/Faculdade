#ifndef MATRIX_H_INCLUDED
#define MATRIX_H_INCLUDED

//aluno : paulo marcelo ribeiros soeiro da silva
//matricula : 20190040030

//Representação da matriz
    struct matrix {
    int data[1000];
    int n_rows;
    int n_cols;
    int stride_rows;
    int stride_cols;
    int offset;
};
//Funções para criação de matrizes
    //create_matrix
        struct matrix create_matrix(int *data, int n_rows, int n_cols);

    //zeros_matrix
        struct matrix zeros_matrix(int n_rows, int n_cols);

    //random_matrix
        struct matrix random_matrix(int n_rows, int n_cols, int b, int e);

    //i_matrix
        struct matrix i_matrix(int n);

// Funções para acessar elementos
    //get_element
        int get_element(struct matrix a_matrix, int ri, int ci);

    //put_element
        void put_element(struct matrix a_matrix, int ri, int ci, int elem);

    //print_matrix
        void print_matrix(struct matrix a_matrix);

//Funções para manipulação de dimensões
    //matrix trasposta
        struct matrix transpose(struct matrix a_matrix);

    //reshape
        struct matrix reshape(struct matrix a_matrix, int new_n_rows, int new_n_cols);

    //flatten
        struct matrix flatten(struct matrix a_matrix);

    //matrix slice
        struct matrix slice(struct matrix a_matrix, int rs, int re, int cs, int ce);

//Funções de agregação
    //sum
        int sum(struct matrix a_matrix);

    //mean
        float mean(struct matrix a_matrix);

    //min
        int minimo(struct matrix a_matrix);

    //max
        int maximo(struct matrix a_matrix);

//Funções de operações aritméticas
    //matrix add
        struct matrix add(struct matrix a_matrix, struct matrix b_matrix);

    //matrix sub
        struct matrix sub(struct matrix a_matrix, struct matrix b_matrix);

    //matrix division
        struct matrix division(struct matrix a_matrix, struct matrix b_matrix);

    //matrix mul
        struct matrix mul(struct matrix a_matrix, struct matrix b_matrix);

    //matrix matmul
        struct matrix matmul(struct matrix a_matrix, struct matrix b_matrix);

#endif // MATRIX_H_INCLUDED

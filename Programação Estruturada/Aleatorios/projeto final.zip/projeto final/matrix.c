#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "matrix.h"

//aluno : paulo marcelo ribeiros soeiro da silva
//matricula : 20190040030

//Funções para criação de matrizes
//create_matrix
struct matrix create_matrix(int *data, int n_rows, int n_cols)
{
    struct matrix principal;
    principal.data[n_rows * n_cols];
    principal.n_rows = n_rows;
    principal.n_cols = n_cols;
    principal.stride_rows = 1;
    principal.stride_cols = 1;
    principal.offset = 0;
    for (int i = 0; i < (n_cols * n_rows); i++)
    {
        principal.data[i] = data[i];
    }
    return principal;
}
//zeros_matrix
struct matrix zeros_matrix(int n_rows, int n_cols)
{
    struct matrix zero;
    zero.n_rows = n_rows;
    zero.n_cols = n_cols;
    zero.stride_rows = 1;
    zero.stride_cols = 1;
    zero.offset = 0;
    for (int i = 0; i < n_rows * n_cols; i++)
    {
        zero.data[i] = 0;
    }
    return zero;
}
//random_matrix
struct matrix random_matrix(int n_rows, int n_cols, int b, int e)
{
    struct matrix random;
    random.data[n_rows * n_cols];
    random.n_rows = n_rows;
    random.n_cols = n_cols;
    random.stride_rows = 1;
    random.stride_cols = 1;
    random.offset = 0;
    for (int i = 0; i < (n_cols * n_rows); i++)
    {
        random.data[i] = b + (rand() % (e + 1 - b));
    }
    return random;
}
//i_matrix
struct matrix i_matrix(int n)
{
    struct matrix ind;
    ind.data[n * n];
    ind.n_rows = n;
    ind.n_cols = n;
    ind.stride_rows = n;
    ind.stride_cols = 1;
    ind.offset = 0;
    int x = 0;
    for (int i = 0; i < (n * n); i++)
    {
        if (i == x)
        {
            ind.data[i] = 1;
            x = x + (ind.stride_rows + ind.stride_cols);
        }
        else
        {
            ind.data[i] = 0;
        }
    }
}
// Funções para acessar elementos
//get_element
int get_element(struct matrix a_matrix, int ri, int ci)
{
    int element = a_matrix.data[((a_matrix.stride_rows * ri)) + (ci)];
    return element;
}
//put_element
void put_element(struct matrix a_matrix, int ri, int ci, int elem)
{
    a_matrix.data[((a_matrix.stride_rows * ri)) + (ci)] = elem;
}
//print_matrix
void print_matrix(struct matrix a_matrix)
{
    printf("\n{");
    for (int x = 0; x < a_matrix.n_rows; x++)
    {
        printf("{");
        for (int y = 0; y < a_matrix.n_cols; y++)
        {
            printf("%d", a_matrix.data[a_matrix.offset]);
            a_matrix.offset++;
            if (y == a_matrix.n_cols - 1)
            {
                printf("}");
            }
            else
            {
                printf(",");
            }
        }
        if (x == a_matrix.n_rows - 1)
        {
            printf("}");
        }
        printf("\n ");
    }
}
//Funções para manipulação de dimensões
//matrix trasposta
struct matrix transpose(struct matrix a_matrix)
{
    struct matrix transpose;
    transpose.data[(a_matrix.n_rows * a_matrix.n_cols)];
    transpose.n_rows = a_matrix.n_cols;
    transpose.n_cols = a_matrix.n_rows;
    transpose.stride_rows = transpose.n_cols;
    transpose.stride_cols = 1;
    transpose.offset = 0;
    for (int i = 0; i < transpose.n_rows; i++)
    {
        for (int j = 0; j < transpose.n_cols; j++)
        {
            transpose.data[transpose.offset] = a_matrix.data[(a_matrix.offset + i)];
            a_matrix.offset = (a_matrix.offset + a_matrix.stride_rows);
            transpose.offset++;
        }
        a_matrix.offset = 0;
    }
    transpose.offset = 0;
    return transpose;
}
//reshape
struct matrix reshape(struct matrix a_matrix, int new_n_rows, int new_n_cols)
{
    if ((new_n_rows * new_n_cols) != (a_matrix.n_rows * a_matrix.n_cols))
    {
        struct matrix reshape;
        reshape.data[(new_n_rows * new_n_cols)];
        reshape.n_rows = new_n_rows;
        reshape.n_cols = new_n_cols;
        reshape.stride_rows = new_n_cols;
        reshape.stride_cols = 1;
        reshape.offset = 0;
        for (int i = 0; i < (new_n_rows * new_n_cols); i++)
        {
            reshape.data[i] = a_matrix.data[i];
        }
        return reshape;
    }

    else
    {
        printf("Dimensões invalidas");
        return a_matrix;
    }
}
//flatten
struct matrix flatten(struct matrix a_matrix)
{
    struct matrix flatten;
    flatten.data[(a_matrix.n_rows * a_matrix.n_cols)];
    flatten.n_rows = 1;
    flatten.n_cols = (a_matrix.n_rows * a_matrix.n_cols);
    flatten.stride_rows = 0;
    flatten.stride_cols = 1;
    flatten.offset = 0;
    for (int i = 0; i < (a_matrix.n_rows * a_matrix.n_cols); i++)
    {
        flatten.data[i] = a_matrix.data[i];
    }
    return flatten;
}
//matrix slice
struct matrix slice(struct matrix a_matrix, int rs, int re, int cs, int ce)
{
    struct matrix slice;
    slice.data[((re - rs) + 1) * ((ce - cs) + 1)];
    slice.n_rows = ((re - rs) + 1);
    slice.n_cols = ((ce - cs) + 1);
    slice.stride_rows = slice.n_cols;
    slice.stride_cols = 1;
    slice.offset = 0;
    int aux = 1;
    for (int i = 0; i < ((re - rs) + 1); i++)
    {
        for (int j = 0; j < ((ce - cs) + 1); j++)
        {
            slice.data[a_matrix.offset] = a_matrix.data[(((a_matrix.stride_rows) * (rs + i))) + (cs) + j];
            a_matrix.offset++;
        }
    }
    return slice;
}
//Funções de agregação
//sum
int sum(struct matrix a_matrix)
{
    int sum;
    for (int i = 0; i < a_matrix.n_cols * a_matrix.n_rows; i++)
    {
        sum = sum + a_matrix.data[i];
        //printf("%d",sum);
    }
    return sum;
}
//mean
float mean(struct matrix a_matrix)
{
    float mean = 0;
    for (int i = 0; i < a_matrix.n_cols * a_matrix.n_rows; i++)
    {
        mean = mean + a_matrix.data[i];
    }
    mean = mean / (a_matrix.n_cols * a_matrix.n_rows);
    //printf("%f",mean);
    return mean;
}
//min
int minimo(struct matrix a_matrix)
{
    int minimo;
    for (int i = 0; i < a_matrix.n_cols * a_matrix.n_rows; i++)
    {
        if (a_matrix.data[i] < minimo)
        {
            minimo = a_matrix.data[i];
        }
    }
    return minimo;
}
//max
int maximo(struct matrix a_matrix)
{
    int maximo;
    for (int i = 0; i < a_matrix.n_cols * a_matrix.n_rows; i++)
    {
        if (a_matrix.data[i] > maximo)
        {
            maximo = a_matrix.data[i];
        }
    }
    return maximo;
}
//Funções de operações aritméticas
//matrix add
struct matrix add(struct matrix a_matrix, struct matrix b_matrix)
{
    struct matrix add;
    add.data[(a_matrix.n_rows) * (a_matrix.n_cols)];
    add.n_rows = (a_matrix.n_rows);
    add.n_cols = (a_matrix.n_cols);
    add.stride_rows = add.n_cols;
    add.stride_cols = 1;
    add.offset = 0;
    for (int i = 0; i < (a_matrix.n_rows) * (a_matrix.n_cols); i++)
    {
        add.data[i] = (a_matrix.data[i]) + (b_matrix.data[i]);
    }
    return add;
}
//matrix sub
struct matrix sub(struct matrix a_matrix, struct matrix b_matrix)
{
    struct matrix sub;
    sub.data[(a_matrix.n_rows) * (a_matrix.n_cols)];
    sub.n_rows = (a_matrix.n_rows);
    sub.n_cols = (a_matrix.n_cols);
    sub.stride_rows = sub.n_cols;
    sub.stride_cols = 1;
    sub.offset = 0;
    for (int i = 0; i < ((a_matrix.n_rows) * (a_matrix.n_cols)); i++)
    {
        sub.data[i] = (a_matrix.data[i]) - (b_matrix.data[i]);
        //printf("%d",sub.data);
    }
    return sub;
}
//matrix division
struct matrix division(struct matrix a_matrix, struct matrix b_matrix)
{
    struct matrix division;
    division.data[(a_matrix.n_rows) * (a_matrix.n_cols)];
    division.n_rows = (a_matrix.n_rows);
    division.n_cols = (a_matrix.n_cols);
    division.stride_rows = division.n_cols;
    division.stride_cols = 1;
    division.offset = 0;
    for (int i = 0; i < ((a_matrix.n_rows) * (a_matrix.n_cols)); i++)
    {
        division.data[i] = (a_matrix.data[i]) / (b_matrix.data[i]);
        //printf("%d",division.data);
    }
    return division;
}
//matrix mul
struct matrix mul(struct matrix a_matrix, struct matrix b_matrix)
{
    struct matrix mul;
    mul.data[(a_matrix.n_rows) * (a_matrix.n_cols)];
    mul.n_rows = (a_matrix.n_rows);
    mul.n_cols = (a_matrix.n_cols);
    mul.stride_rows = mul.n_cols;
    mul.stride_cols = 1;
    mul.offset = 0;
    for (int i = 0; i < ((a_matrix.n_rows) * (a_matrix.n_cols)); i++)
    {
        mul.data[i] = (a_matrix.data[i] * b_matrix.data[i]);
    }
    return mul;
}
//matrix matmul
struct matrix matmul(struct matrix a_matrix, struct matrix b_matrix)
{
    int data_matmul[(a_matrix.n_rows) * (a_matrix.n_cols)];
    int indice, value = 0, i = 0, j = 0, k = 0, fat = 0, aux = 1;

    while (a_matrix.n_rows--)
    {
        for (; i < a_matrix.n_cols * b_matrix.n_cols;)
        {
            aux = i / b_matrix.n_cols;
            value += a_matrix.data[i] * b_matrix.data[j];
            i++;
            j += b_matrix.n_cols;

            if (j > ((pow(b_matrix.n_cols, 2) - (b_matrix.n_cols) + fat) + 1))
            {
                j = fat;
                indice = i == b_matrix.n_cols ? fat : fat + b_matrix.n_cols * (aux);
                data_matmul[indice] = value;
                value = 0;
            }
            if (i == pow(b_matrix.n_cols, 2))
            {
                break;
            } 
            aux = 0;
        }
        ++fat;
        j = fat;
        i = 0;
    }
    struct matrix MatMul = create_matrix(data_matmul, b_matrix.n_cols, b_matrix.n_cols);

    return MatMul;
};
